# Typing effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/George127/pen/yLVNVMa](https://codepen.io/George127/pen/yLVNVMa).

